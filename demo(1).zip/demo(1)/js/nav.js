function dis() {
    var temp=$("li");
    if(temp[0].style.display !== "none"){
        for(var i = 0;i < 4;i ++){
            temp[i].style.display = "none"
        }
        $("#button1").text("显示");
    }
    else {
        for(var i = 0;i < 4;i ++){
            temp[i].style.display = "inline-block"
        }
        $("#button1").text("隐藏");
    }
}
function myFunction(x) {
    if (x.matches) { // 媒体查询
        var temp = $("li");
        if (temp[0].style.display === "none") {
            for (var i = 0; i < 4; i++) {
                temp[i].style.display = "inline-block"
            }
        }
    }
}