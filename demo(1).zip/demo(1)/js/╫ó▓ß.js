// 用户名验证
    function checkUserName() {
        var userName = $("#userName").val();
        if (userName.length >= 3 && userName.length <= 15) {
            //符合长度要求
            //1：不是数字开头的
            var c = userName.charAt(0);
            if (isNaN(c)) {
                //非数字开头--符合要求
                $("#userNameShow").text("验证通过");
                $("#userNameShow").css("color","green");
                return true;
            } else {
                //数字开头
                $("#userNameShow").text("不能以数字开头");
                $("#userNameShow").css("color","red");
                return false;
            }
        } else { //不符合长度要求
            $("#userNameShow").text("长度不符合要求");
            $("#userNameShow").css("color","red");
            return false;
        }
    }
    // 密码验证
    function checkPwd() {
        var pwd = $("#pwd1").val();
        if (pwd.length >= 6 && pwd.length <= 18) {
            //1:纯数字
            var pwdReg = /(\D+\d+) |(\d+\D)/;
            if (pwdReg.test(pwd)) {
                $("#pwdShow1").text("验证通过");
                $("#pwdShow1").css("color","green");
                return true;
            } else {
                $("#pwdShow1").text("不能是纯字符");
                $("#pwdShow1").css("color","red");
                return false;
            }
        } else {
            $("#pwdShow1").text("长度不符合要求");
            $("#pwdShow1").css("color","red");
            return false;
        }
    }
    // 确认密码再次验证
    function checkpwd2(){
        var pwd1 = $("#pwd1").val();
        var pwd2 = $("#pwd2").val();
        if (pwd1==pwd2) {
            $("#pwdShow2").text("验证通过");
            $("#pwdShow2").css("color","green");
            return true;
        }else{
            $("#pwdShow2").text("两次密码不一样");
            $("#pwdShow2").css("color","red");
            return false;
        }
    }
    // 手机号验证
    function checkphone(){
                var phone = $("#phone").val();
                var myreg=/^[1][3,4,5,7,8][0-9]{9}$/;
                if (!myreg.test(phone)) {
                    $("#phoneshow").text("手机号格式错误");
                    $("#phoneshow").css("color","red");
                    return false;
                } else {
                    $("#phoneshow").text("验证通过");
                    $("#phoneshow").css("color","green");
                    return true;
                }
    }
    // 邮箱验证
    function checkemail(obj){
                var email=$('#email').val();
                if(email.match(/^(.+)@(.+)$/)){
                    $("#emailshow").text("验证通过");
                    $("#emailshow").css("color","green");
                    return true;
                }else{
                    $("#emailshow").text("邮箱格式错误");
                    $("#emailshow").css("color","red");
                    return false;
                }
            }

    function reg() {
        if (checkUserName() && checkPwd()&&checkpwd2()&&checkphone()&&checkemail()){
            alert("注册通过！跳转至首页！");
            window.open('../html/人物生平.html');
        }else{
            alert("注册失败，请重新注册！");
        }
    }
    function reg_a() {
            alert("请通过注册登录！");
    }