function getTime() {
    var data = new Date();
    return (data.getFullYear() + "-" + (data.getMonth() + 1) + "-" + data.getDate() + " " + data.getHours() + "时" + data.getMinutes() + "分" + data.getSeconds() + "秒");
   }
$(document).ready(function(){
$("#btn1").click(function(){
    var text = $("#comment").val();
    if(text === ""){ alert("评论不能为空") 
    return;
    }
    var txt=$("<p></p>").text(text);  
    var sptime=$("<p></p><hr>").text(getTime());
    $("#rediv").append(txt,sptime);  
    $("#comment").val("");
});
// $("#comment").blur(function(){
//         var text = $("#comment").val();
//         if(text === ""){ alert("评论不能为空") 
//         return;
//         }
//         var txt=$("<p></p>").text(text);  
//         var sptime=$("<p></p><hr>").text(getTime());
//         $("#rediv").append(txt,sptime);  
//         $("#comment").val("");
// });
        var vs = $(".dc");
		for (var i = 0; i < vs.length; i++) {
			vs[i].onclick = function () {
				if (this.style.color !== 'red') {
					this.style.color = 'red';
				}
				else {
					this.style.color = "rgb(0, 0, 0)";
				}
			}
		}
})
